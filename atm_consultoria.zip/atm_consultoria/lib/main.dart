import 'package:flutter/material.dart';
import 'Home.dart';

void main() => runApp(MaterialApp(
  debugShowCheckedModeBanner: false,
  home: Home(),
));

